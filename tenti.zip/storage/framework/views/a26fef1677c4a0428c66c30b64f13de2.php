<?php $__env->startSection('head'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('head'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?><?php echo e($category->seo_title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?><?php echo e($category->seo_description); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container">
            <h1 class="service-title"><?php echo e($category->name); ?></h1>
            <div class="row">
                <div class="col-12 col-lg-5">
                    <div class="service-media">
                        <img src="<?php echo e($category->img); ?>" alt="<?php echo e($category->name); ?>" class="service-img">
                    </div>
                </div>
                <div class="col-12 col-lg-7">
                    <div class="service-list">
                        <?php $__currentLoopData = $category->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="service-row">
                            <div class="service-name"><?php echo e($service->name); ?></div>
                            <div class="service-price">
                                <?php if($service->is_price_individual): ?>
                                    <strong>Инд. расчет</strong>
                                <?php else: ?>
                                    <?php if($service->is_price_from): ?>
                                        <strong>От <?php echo e($service->price); ?> &#8381;</strong>
                                    <?php else: ?>
                                        <strong><?php echo e($service->price); ?> &#8381;</strong>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="service-description">
                        <?php echo e($category->description); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('footer'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\OSPanel\domains\tenti\resources\views/templates/service.blade.php ENDPATH**/ ?>